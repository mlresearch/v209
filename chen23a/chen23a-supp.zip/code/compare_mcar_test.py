import pandas as pd
import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib import gridspec
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from interpret.glassbox import ExplainableBoostingClassifier
from interpret import show
from sklearn.metrics import roc_auc_score
import os
from scipy.stats import norm

import rpy2
from rpy2.robjects.packages import importr
from rpy2 import robjects
import rpy2.robjects.numpy2ri
rpy2.robjects.numpy2ri.activate()
from rpy2.robjects import pandas2ri
pandas2ri.activate()
base = importr('base')
naniar = importr('naniar')

def load_mimic2():
    with open('./mimic2/mimic2.attr') as f:
        featureNames = []
        for line in f.readlines():
            featureNames.append(line[:line.find(':')])
            
    # with open('./mimic2/mimic2_cont_missing.data') as f:
    #     data_orig = pd.read_csv(f,' ',header=None, na_values='N/A')
    with open('./mimic2/mimic2_cont_rfimputed.data') as f:
        data_rf = pd.read_csv(f,' ',header=None, na_values='N/A')
    # with open('./datasets/mimic2/mimic2_cont_knnimputed.data') as f:
    #     data_knn = pd.read_csv(f,' ',header=None, na_values='N/A')
        
    # data_orig.columns = featureNames
    # # data_mean.columns = featureNames
    data_rf.columns = featureNames
    # data_knn.columns = featureNames
    # print(data_orig)
    return data_rf

def get_onehot(ebm, X):
    
    featureNames=list(X.columns)
    # print(ebm.feature_names)
    # print(X.columns)
    n = X.shape[0]
    X_binary = [np.ones((n,1))]
    betas = [ebm.intercept_[0]]
    for i, feature in enumerate(featureNames):
        if type(ebm.bins_[i][0])==type({}):
            x_bin_sub = np.zeros((n, int(X[feature].max())+1))
            x_bin_sub[np.arange(n),X[feature].astype('int')]=1
        else:
            bins = [-10000]+list(ebm.bins_[i][0])+[10000]
            bins = np.array(bins)
            x_idx = np.digitize(X[feature],bins,right=True)
            assert(x_idx.min()==1 and x_idx.max()+1==bins.shape[0])
            x_bin_sub = np.zeros((n, x_idx.max()))
            x_bin_sub[np.arange(n),x_idx-1]=1
        
        X_binary.append(x_bin_sub)
        term_scores = ebm.term_scores_[i][1:-1]
        betas+=list(term_scores)
        # print(term_scores.shape, x_bin_sub.shape)

    
    X_binary = np.concatenate(X_binary,1)
    betas = np.array(betas)
    # print(X_binary.shape, betas.shape)
    return X_binary, betas

def littles_test(data):
    """
    X, y: numpy arrays. X shape is n*(p+1) and y is either 1 or -1. 
    """

    # print("load package")

    # d = {'package.dependencies': 'package_dot_dependencies', 'package_dependencies': 'package_uscore_dependencies'}
    # FastSparse = importr('mcartest', robject_translations = d)

    res = naniar.mcar_test(data)
    # print(res)
    res = base.as_matrix(res)
    res = np.asarray(res)
    p = res[0,2]
    return p


data_rf = load_mimic2()
data_rf_np = data_rf.to_numpy()
p_miss = 0.1
for missing_type in ('mcar', 'mar'):
    p_little_list = []
    p_ours_list = []
    for t in range(200):
        data_np = data_rf_np.copy()
        if missing_type=='mcar':
            missing_prob = np.random.uniform(size=data_np.shape[0])
            is_missing = missing_prob<p_miss
        elif missing_type=='mar':
            coef = np.random.normal(size=data_np.shape[1]-1)
            scaler = StandardScaler()
            data_normalized = scaler.fit_transform(data_np)
            scores = (data_normalized[:,1:] * coef).sum(1)
            is_missing = scores<np.quantile(scores,p_miss)
            
        data_np[is_missing,0] = None
        df = pd.DataFrame(data_np)
        p_little = littles_test(df)
        p_little_list.append(p_little)
        print(f'iteration {t}, Littles test p={p_little}',flush=True)

        data_np[is_missing,0] = -5
        df = pd.DataFrame(data_np)
        df.columns = data_rf.columns
        feature_cols, label_col = df.columns[0:-1], df.columns[-1]
        X, y = df[feature_cols], df[label_col]
        ebm = ExplainableBoostingClassifier(outer_bags = 30, inner_bags= 5, interactions=0,random_state=1, n_jobs=4)
        ebm.fit(X, y)   #Works on dataframes and numpy arrays
        p_X = ebm.predict_proba(X)
        X_binary, betas = get_onehot(ebm,X)
        fisher = (X_binary.T * (p_X[:,0] * p_X[:,1]).reshape(-1)) @ X_binary
        cov = np.linalg.pinv(fisher)
        standard_error = np.sqrt(np.diag(cov))
        p_values = (1 - norm.cdf(abs(betas/standard_error))) * 2
        p_ours  = p_values[1]
        p_ours_list.append(p_ours)
        print(f'iteration {t}, ours test p={p_ours}',flush=True)

    p_little_arr = np.array(p_little_list)
    p_ours_arr = np.array(p_ours_list)
    np.save(f'./results/p_little_arr_{p_miss}_{missing_type}.npy', p_little_arr)
    np.save(f'./results/p_ours_arr_{p_miss}_{missing_type}.npy', p_ours_arr)



