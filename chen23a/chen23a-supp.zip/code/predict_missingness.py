import pandas as pd
import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib import gridspec
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from interpret.glassbox import ExplainableBoostingClassifier
from interpret import show
from sklearn.metrics import roc_auc_score, accuracy_score
import os
from scipy.stats import norm

from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier

import rpy2
from rpy2.robjects.packages import importr
from rpy2 import robjects
import rpy2.robjects.numpy2ri
rpy2.robjects.numpy2ri.activate()
from rpy2.robjects import pandas2ri
pandas2ri.activate()
base = importr('base')
naniar = importr('naniar')

def load_mimic2():
    with open('./mimic2/mimic2.attr') as f:
        featureNames = []
        for line in f.readlines():
            featureNames.append(line[:line.find(':')])
            
    # with open('./mimic2/mimic2_cont_missing.data') as f:
    #     data_orig = pd.read_csv(f,' ',header=None, na_values='N/A')
    with open('./mimic2/mimic2_cont_rfimputed.data') as f:
        data_rf = pd.read_csv(f,' ',header=None, na_values='N/A')
    # with open('./datasets/mimic2/mimic2_cont_knnimputed.data') as f:
    #     data_knn = pd.read_csv(f,' ',header=None, na_values='N/A')
        
    # data_orig.columns = featureNames
    # # data_mean.columns = featureNames
    data_rf.columns = featureNames
    # data_knn.columns = featureNames
    # print(data_orig)
    return data_rf


data_rf = load_mimic2()
data_rf_np = data_rf.to_numpy()
p_miss = 0.1
for missing_type in ('mar-linear', 'mar-curvilinear', 'mar-quadratic', 'mnar-linear', 'mnar-curvilinear', 'mnar-quadratic'):
# for missing_type in ('mnar-quadratic',):
    accs_lr = []
    accs_rf = []
    accs_knn = []
    accs_ebm = []
    for t in range(200):
        print(f'-----------------iteration {t}/200-----------------')
        data_np = data_rf_np.copy()
        if missing_type=='mar-linear':
            coef = np.random.normal(size=data_np.shape[1]-1)
            scaler = StandardScaler()
            data_normalized = scaler.fit_transform(data_np)
            scores = (data_normalized[:,1:] * coef).sum(1)
            noise = np.random.normal(size=data_np.shape[0])
            is_missing = (scores+noise)<np.quantile(scores,p_miss)
        elif missing_type=='mar-curvilinear':
            coef_1 = np.random.normal(size=data_np.shape[1]-1)
            coef_2 = np.random.normal(size=data_np.shape[1]-1)
            scaler = StandardScaler()
            data_normalized = scaler.fit_transform(data_np)
            scores = ((data_normalized[:,1:] * coef_1 + coef_2) ** 2).sum(1)
            noise = np.random.normal(size=data_np.shape[0])
            is_missing = (scores+noise)<np.quantile(scores,p_miss)
        elif missing_type=='mar-quadratic':
            coef_1 = np.random.normal(size=data_np.shape[1]-1)
            coef_2 = np.random.normal(size=1)
            scaler = StandardScaler()
            data_normalized = scaler.fit_transform(data_np)
            scores = ((data_normalized[:,1:] * coef_1).sum(1)+coef_2)**2
            noise = np.random.normal(size=data_np.shape[0])
            is_missing = (scores+noise)<np.quantile(scores,p_miss)
        elif missing_type=='mnar-linear':
            coef = np.random.normal(size=data_np.shape[1])
            scaler = StandardScaler()
            data_normalized = scaler.fit_transform(data_np)
            scores = (data_normalized * coef).sum(1)
            noise = np.random.normal(size=data_np.shape[0])
            is_missing = (scores+noise)<np.quantile(scores,p_miss)
        elif missing_type=='mnar-curvilinear':
            coef_1 = np.random.normal(size=data_np.shape[1])
            coef_2 = np.random.normal(size=data_np.shape[1])
            scaler = StandardScaler()
            data_normalized = scaler.fit_transform(data_np)
            scores = ((data_normalized * coef_1 + coef_2) ** 2).sum(1)
            noise = np.random.normal(size=data_np.shape[0])
            is_missing = (scores+noise)<np.quantile(scores,p_miss)
        elif missing_type=='mnar-quadratic':
            coef_1 = np.random.normal(size=data_np.shape[1])
            coef_2 = np.random.normal(size=1)
            scaler = StandardScaler()
            data_normalized = scaler.fit_transform(data_np)
            scores = ((data_normalized * coef_1).sum(1)+coef_2)**2
            noise = np.random.normal(size=data_np.shape[0])
            is_missing = (scores+noise)<np.quantile(scores,p_miss)

        data_np = np.c_[data_np,is_missing.reshape(-1,1)] 
        df = pd.DataFrame(data_np)
        df.columns = list(data_rf.columns) + ['missingness']
        feature_cols, label_col = df.columns[:-1], df.columns[-1]
        X, y = df[feature_cols], df[label_col].astype('int')
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # logistic regression
        lr = LogisticRegression(max_iter=1000, solver='liblinear')
        lr.fit(X_train,y_train)
        acc_lr = lr.score(X_test, y_test)
        accs_lr.append(acc_lr)
        print(f'test accuracy Logistic Regression: {acc_lr}', flush = True)
        # random forest
        rf = RandomForestClassifier(n_estimators=200)
        rf.fit(X_train,y_train)
        acc_rf = rf.score(X_test, y_test)
        accs_rf.append(acc_rf)
        print(f'test accuracy Random Forest: {acc_rf}', flush = True)
        # KNN
        knn = KNeighborsClassifier(n_neighbors=10)
        knn.fit(X_train,y_train)
        acc_knn = knn.score(X_test, y_test)
        accs_knn.append(acc_knn)
        print(f'test accuracy K Nearest Neighbor: {acc_knn}', flush = True)
        # ebm
        if missing_type == 'mar-quadratic' or missing_type == 'mnar-quadratic':
            ebm = ExplainableBoostingClassifier(interactions=20, random_state=1, n_jobs=1)
        else:
            ebm = ExplainableBoostingClassifier(interactions=0, random_state=1, n_jobs=1)
        ebm.fit(X_train,y_train)   #Works on dataframes and numpy arrays
        acc_ebm = ebm.score(X_test, y_test)
        accs_ebm.append(acc_ebm)
        print(f'test accuracy EBM: {acc_ebm}', flush = True)

        
    accs_lr = np.array(accs_lr)
    accs_rf = np.array(accs_rf)
    accs_knn = np.array(accs_knn)
    accs_ebm = np.array(accs_ebm)

    np.save(f'./results/accs_lr_{p_miss}_{missing_type}.npy', accs_lr)
    np.save(f'./results/accs_rf_{p_miss}_{missing_type}.npy', accs_rf)
    np.save(f'./results/accs_knn_{p_miss}_{missing_type}.npy', accs_knn)
    np.save(f'./results/accs_ebm_{p_miss}_{missing_type}.npy', accs_ebm)



