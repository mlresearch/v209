# database parameters
db_name                     = 'placeholder'
nonstationarity_schema_name = 'placeholder'

# directory parameters
cache_dir        = 'placeholder'
omop_data_dir    = 'placeholder'
outcome_data_dir = 'placeholder'
experiment_dir   = 'placeholder'
logging_dir      = 'placeholder'
interaction_dir  = 'placeholder'

domain_shift_dir = 'placeholder'