import torch
import torch.nn
import torch.optim
from torch import nn
from torchpack.utils.config import configs
from torchpack.utils.typing import Optimizer, Scheduler

__all__ = [
    'make_dataset', 'make_model', 'make_criterion', 'make_optimizer',
    'make_scheduler'
]


def make_dataset(ensembled, mean=None, std=None, part=None, split_ratio=None):
    if configs.dataset.name == 'anon_dataset_name':
        from core.datasets import AnonDatasetName
        dataset = AnonDatasetName(root=configs.dataset.root,
                             split_ratio=configs.dataset.split_ratio if split_ratio is None else split_ratio,
                             custom_split_indices=configs.dataset.custom_split_indices,
                             beats_per_subject=configs.dataset.beats_per_subject,
                             subject_name=getattr(configs.dataset, 'subject_name', None),
                             target=getattr(configs.dataset, 'target', 'map'),
                             part=configs.dataset.part if part is None else part,
                             mean=mean,
                             std=std,
                             ensembled=ensembled,
                             )
    else:
        raise NotImplementedError(configs.dataset.name)
    return dataset


def make_model() -> nn.Module:
    if configs.model.name == 'fc':
        from core.models import FC
        model = FC(in_ch=configs.model.in_ch,
                   out_ch=configs.model.out_ch,
                   layer_num=configs.model.layer_num,
                   dropout=configs.model.dropout,)
    elif configs.model.name == 'attn':
        from core.models import Attn
        model = Attn(in_ch=configs.model.in_ch,
                     out_ch=configs.model.out_ch,
                     n_head=configs.model.n_head,
                     layer_num=configs.model.layer_num,
                     dropout=configs.model.dropout,)
    elif configs.model.name == 'conv':
        from core.models import Conv
        model = Conv(in_ch=configs.model.in_ch,
                     out_ch=configs.model.out_ch,
                     kernel_size=configs.model.kernel_size,
                     stride=configs.model.stride,
                     padding=configs.model.padding,
                     layer_num=configs.model.layer_num,
                     dropout=configs.model.dropout)
    elif configs.model.name == 'lstm':
        from core.models import Lstm
        model = Lstm(in_ch=configs.model.in_ch,
                     out_ch=configs.model.out_ch,
                     bidirectional=configs.model.bidirectional,
                     layer_num=configs.model.layer_num,
                     dropout=configs.model.dropout)
    else:
        raise NotImplementedError(configs.model.name)
    return model


def make_criterion() -> nn.Module:
    if configs.criterion.name == 'mse':
        criterion = nn.MSELoss()
    elif configs.criterion.name == 'std_error_over_mean_error':
        from .criterions import std_error_over_mean_error
        criterion = std_error_over_mean_error
    elif configs.criterion.name == 'std_error_over_mean_error_abs':
        from .criterions import std_error_over_mean_error_abs
        criterion = std_error_over_mean_error_abs
    elif configs.criterion.name == 'std_error_times_mean_error_abs':
        from .criterions import std_error_times_mean_error_abs
        criterion = std_error_times_mean_error_abs
    elif configs.criterion.name == 'std_error':
        from .criterions import std_error
        criterion = std_error
    elif configs.criterion.name == 'mae':
        criterion = nn.L1Loss()
    else:
        raise NotImplementedError(configs.criterion.name)
    return criterion


def make_optimizer(model: nn.Module) -> Optimizer:
    if configs.optimizer.name == 'sgd':
        optimizer = torch.optim.SGD(
            model.parameters(),
            lr=configs.optimizer.lr,
            momentum=configs.optimizer.momentum,
            weight_decay=configs.optimizer.weight_decay)
    elif configs.optimizer.name == 'adam':
        optimizer = torch.optim.Adam(
            model.parameters(),
            lr=configs.optimizer.lr,
            weight_decay=configs.optimizer.weight_decay)
    else:
        raise NotImplementedError(configs.optimizer.name)
    return optimizer


def make_scheduler(optimizer: Optimizer) -> Scheduler:
    if configs.scheduler.name == 'cosine':
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=configs.num_epochs,
            eta_min=0)
    elif configs.scheduler.name == 'constant':
        scheduler = torch.optim.lr_scheduler.LambdaLR(
            optimizer,
            lr_lambda=lambda epoch: 1,
        )
    else:
        raise NotImplementedError(configs.scheduler.name)
    return scheduler
